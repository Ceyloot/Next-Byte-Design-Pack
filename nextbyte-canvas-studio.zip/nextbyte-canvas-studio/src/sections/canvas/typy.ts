/**
 * Model kanwy generatywnej.
 *
 * Nazwy pól są celowo takie same jak w `canvasStore.ts` z NextByteArt
 * (`layerId`, `normalizedX`…), mimo że reszta repo mówi po polsku. Dzięki
 * temu przeniesienie tamtejszej integracji z modelem nie wymaga tłumaczenia
 * struktur — a to jest ważniejsze niż spójność słownika w jednym folderze.
 */

export type Narzedzie = 'wybor' | 'pineska' | 'reka' | 'ramka' | 'pedzel'

/** Pociągnięcie pędzla do inpaintingu: punkty (0–1 względem zdjęcia) i średnica jako ułamek szerokości zdjęcia. */
export interface Pociagniecie {
  layerId: string
  punkty: [number, number][]
  srednica: number
}

export type ZrodloObrazu = 'dysk' | 'schowek' | 'upuszczenie' | 'adres' | 'wynik'

export interface Warstwa {
  id: string
  type: 'image'
  src: string
  x: number
  y: number
  width: number
  height: number
  /** oryginalna rozdzielczość — model dostaje pełną jakość, nie podgląd */
  naturalWidth: number
  naturalHeight: number
  rotation: number
  name: string
  visible: boolean
  locked: boolean
  /** skąd obraz trafił na płótno — przydaje się przy diagnozie */
  zrodlo: ZrodloObrazu
  /** pusta ramka generatora („Image Generator”) — czeka na opis, nie jest zdjęciem do edycji */
  generator?: boolean
  /** trwa generowanie obrazu w tej ramce — animowany placeholder zamiast zdjęcia */
  generuje?: boolean
  /** tymczasowy placeholder tworzony obok zdjęcia na czas generacji (znika po wyniku; nie jest zapisywany) */
  duch?: boolean
  /**
   * Co widać na zdjęciu — rozpoznane w tle zaraz po wrzuceniu.
   * Służy za zapas nazw dla pinesek i za kontekst dla polecenia.
   */
  obiekty?: string[]
}

/** Dedykowana paleta 10 wyrazistych kolorów dla kolejnych pinesek */
export const KOLORY_PINESEK = [
  '#0284c7', // 1: Sky blue
  '#c026d3', // 2: Fuchsia / Purple
  '#16a34a', // 3: Emerald
  '#ea580c', // 4: Orange
  '#eab308', // 5: Yellow
  '#dc2626', // 6: Red
  '#06b6d4', // 7: Cyan
  '#8b5cf6', // 8: Violet
  '#ec4899', // 9: Pink
  '#10b981', // 10: Teal
]

/**
 * Pineska = zaznaczony obiekt na zdjęciu.
 *
 * To nie jest komentarz ani rola w scenariuszu, tylko **nazwany uchwyt**:
 * wbijasz ją w laptopa, nazywasz „laptop”, i od tej chwili możesz o nim
 * mówić w poleceniu jako o konkretnej rzeczy, zamiast opisywać słowami,
 * który z siedmiu obiektów na zdjęciu masz na myśli.
 */
/** Prostokąt w ułamkach kadru (0–1). */
export interface RamkaObiektu {
  x0: number
  y0: number
  x1: number
  y1: number
}

export interface Pineska {
  id: string
  layerId: string
  /** współrzędne 0–1 względem warstwy, żeby przeżyły skalowanie obrazu */
  normalizedX: number
  normalizedY: number
  /** nazwa obiektu — to ona trafia do polecenia jako chip */
  label: string
  /**
   * Propozycje nazwy z rozpoznawania obrazu. Puste, dopóki model nie jest
   * podpięty; pole istnieje, żeby podpięcie nie wymagało zmiany modelu.
   */
  sugestie?: string[]
  /** true, gdy trwa rozpoznawanie — pineska pokazuje wtedy pulsowanie */
  analizowana?: boolean
  /**
   * Pineska chroniąca zamiast wskazującej.
   *
   * Domyślnie pineska jest uchwytem: nazywa obiekt, o którym mówisz
   * w poleceniu. Z tą flagą znaczy coś przeciwnego — „tego nie ruszaj” —
   * i trafia do polecenia jako obszar chroniony.
   */
  chroniona?: boolean
  /**
   * Analiza zaraz po wbiciu: cały obiekt pod pineską, otoczenie i rzeczywiste
   * wymiary z kalibracji na punktach odniesienia w kadrze (koło, drzwi,
   * człowiek) — nigdy z przeliczania pikseli. Reżyser dostaje to jako fakty,
   * więc skala zamiany wynika z liczb, a nie z obrysu starego obiektu.
   */
  analiza?: AnalizaPineski
  /** Ramka całego obiektu pod pineską (z rozpoznawania) — tylko do podglądu, nie trafia do modelu. */
  ramka?: RamkaObiektu
}

export interface AnalizaPineski {
  /** cały obiekt po polsku, np. „Ford GT40 Mk II, ciemnoniebieski, w kurzu” */
  obiekt: string
  /** to samo po angielsku — do promptu */
  obiektEn: string
  /** co jest wokół, po angielsku */
  otoczenie: string
  wysokoscCm?: number
  dlugoscCm?: number
  /** ± w cm */
  niepewnoscCm?: number
  /** jak skalibrowano, po polsku, np. „koło 15″ ≈ 66 cm, dach na 1,55 koła” */
  kalibracja: string
  /** gdy pineska stoi na styku dwóch rzeczy, np. „auto i osoba przy drzwiach” */
  dwuznacznosc?: string
  /** Kto lub co wchodzi w interakcję (np. osoba oparta o drzwi, dłonie na laptopie, dłoń trzymająca obiekt) */
  interakcja?: string
  /** Kąt i orientacja 3D (np. widok 3/4 z lewej, drzwi otwarte pod kątem 40°) */
  pozycja3d?: string
  /** Stan powierzchni i patyna (np. gruba warstwa kurzu ze stodoły, matowy lakier, zabrudzenia) */
  stanPowierzchni?: string
  /** Plan głębi i optyka (pierwszy plan, średni plan, tło; ostry vs rozmyty bokeh soczewki) */
  glebiaOptyka?: string
  /** Źródła i wektory światła (kąt słońca, kolor, cienie, neonowe rim-lights) */
  swiatloWektory?: string
}

/**
 * Obszar roboczy zaznaczony ramką (prostokąt inpaintingu).
 * Współrzędne znormalizowane 0–1 względem wymiarów warstwy.
 */
export interface RamkaObszaru {
  layerId: string
  x0: number
  y0: number
  x1: number
  y1: number
  etykieta?: string
}

let licznik = 0
export function nowyId(prefiks = 'w'): string {
  licznik += 1
  return `${prefiks}${Date.now().toString(36)}${licznik.toString(36)}`
}

export interface Widok {
  x: number
  y: number
  zoom: number
}

/** Pozycja pineski w układzie płótna — z powrotem z 0–1 na piksele. */
export function pozycjaPineski(p: Pineska, warstwa: Warstwa): { x: number; y: number } {
  return {
    x: warstwa.x + p.normalizedX * warstwa.width,
    y: warstwa.y + p.normalizedY * warstwa.height,
  }
}

/**
 * Nazwa pokazywana, gdy użytkownik jeszcze nic nie wpisał.
 *
 * `label` bywa nieobecne w projektach zapisanych przed wprowadzeniem tego
 * pola, więc nie zakładamy, że jest stringiem — inaczej stary wpis
 * w localStorage wywraca cały widok.
 */
export function etykietaPineski(p: Pineska, numer: number): string {
  return (p.label ?? '').trim() || `obiekt ${numer}`
}

/**
 * Doprowadza wczytany projekt do bieżącego kształtu modelu.
 *
 * Pineski z wcześniejszej wersji miały `role` i `description` zamiast
 * `label`; warstwy nie miały `zrodlo`. Migrujemy przy odczycie, bo wersja
 * zapisu nie jest warta osobnego pola, a użytkownik nie powinien tracić
 * pracy przy każdej zmianie modelu.
 */
export function wczytajProjekt(dane: unknown): { warstwy: Warstwa[]; pineski: Pineska[]; tekst: string; ramka?: RamkaObszaru | null } {
  const surowe = (dane ?? {}) as Record<string, unknown>
  const warstwy = Array.isArray(surowe.warstwy) ? (surowe.warstwy as Record<string, unknown>[]) : []
  const pineski = Array.isArray(surowe.pineski) ? (surowe.pineski as Record<string, unknown>[]) : []

  let ramka: RamkaObszaru | null = null
  if (surowe.ramka && typeof surowe.ramka === 'object') {
    const r = surowe.ramka as Record<string, unknown>
    if (typeof r.layerId === 'string' && Number.isFinite(r.x0) && Number.isFinite(r.y0) && Number.isFinite(r.x1) && Number.isFinite(r.y1)) {
      ramka = {
        layerId: String(r.layerId),
        x0: Number(r.x0),
        y0: Number(r.y0),
        x1: Number(r.x1),
        y1: Number(r.y1),
        etykieta: typeof r.etykieta === 'string' ? r.etykieta : undefined,
      }
    }
  }

  return {
    warstwy: warstwy
      .filter(w => typeof w?.src === 'string')
      .map(w => ({
        id: String(w.id ?? nowyId('w')),
        type: 'image' as const,
        src: String(w.src),
        x: Number(w.x) || 0,
        y: Number(w.y) || 0,
        width: Number(w.width) || 200,
        height: Number(w.height) || 150,
        naturalWidth: Number(w.naturalWidth) || Number(w.width) || 200,
        naturalHeight: Number(w.naturalHeight) || Number(w.height) || 150,
        rotation: Number(w.rotation) || 0,
        name: String(w.name ?? 'Zdjęcie'),
        visible: w.visible !== false,
        locked: w.locked === true,
        zrodlo: (['dysk', 'schowek', 'upuszczenie', 'adres', 'wynik'] as const).includes(w.zrodlo as ZrodloObrazu)
          ? (w.zrodlo as ZrodloObrazu)
          : 'dysk',
        obiekty: Array.isArray(w.obiekty) ? (w.obiekty as string[]) : undefined,
      })),
    pineski: pineski
      .filter(p => typeof p?.layerId === 'string')
      .map(p => ({
        id: String(p.id ?? nowyId('p')),
        layerId: String(p.layerId),
        normalizedX: Number(p.normalizedX) || 0,
        normalizedY: Number(p.normalizedY) || 0,
        // `description` to nazwa z poprzedniej wersji modelu.
        label: String(p.label ?? p.description ?? ''),
        sugestie: Array.isArray(p.sugestie) ? (p.sugestie as string[]) : undefined,
        chroniona: p.chroniona === true,
      })),
    tekst: typeof surowe.tekst === 'string' ? surowe.tekst : typeof surowe.opis === 'string' ? surowe.opis : '',
    ramka,
  }
}


/**
 * Położenie pineski opisane słowami.
 *
 * Model nie przelicza „46%, 67%” na miejsce w kadrze — procenty są dla
 * niego szumem. „w dolnej części, pośrodku” trafia dużo celniej, bo tak
 * opisują sceny podpisy, na których był trenowany.
 */
export function opiszPolozenie(normalizedX: number, normalizedY: number): string {
  // Pięć pasów zamiast trzech: przy siatce 3×3 „na dole po lewej” obejmowało
  // jedną dziewiątą kadru i model trafiał w zupełnie inne miejsce.
  const pas = (v: number, nazwy: [string, string, string, string, string]) =>
    v < 0.18 ? nazwy[0] : v < 0.4 ? nazwy[1] : v < 0.6 ? nazwy[2] : v < 0.82 ? nazwy[3] : nazwy[4]

  const pion = pas(normalizedY, [
    'przy górnej krawędzi',
    'w górnej części',
    'w połowie wysokości',
    'w dolnej części',
    'przy dolnej krawędzi',
  ])
  const poziom = pas(normalizedX, [
    'przy lewej krawędzi',
    'w lewej części',
    'pośrodku szerokości',
    'w prawej części',
    'przy prawej krawędzi',
  ])
  return `${pion}, ${poziom}`
}

/**
 * Kolejność zdjęć wysyłanych do modelu.
 *
 * Pierwsze jest to, które edytujemy — w jego kadrze i proporcjach wróci
 * wynik. Dalej idą pozostałe zdjęcia z pineskami, bo skoro coś na nich
 * zaznaczono, to polecenie się na nie powołuje („weź tę altanę stamtąd”).
 * Bez nich model dostawał tylko jeden obraz i nie miał skąd wziąć obiektu.
 */
export function kolejnoscObrazow(
  warstwaEdytowana: Warstwa | null,
  pineski: Pineska[],
  warstwy: Warstwa[],
): Warstwa[] {
  const wynik: Warstwa[] = []
  const dodaj = (w?: Warstwa) => {
    if (w && !wynik.some(x => x.id === w.id)) wynik.push(w)
  }
  dodaj(warstwaEdytowana ?? undefined)
  for (const p of pineski) dodaj(warstwy.find(w => w.id === p.layerId))
  // Tylko zdjęcie edytowane i zdjęcia z pineskami. Wcześniej szła każda widoczna
  // warstwa — także poprzednie wyniki bez pinesek, a model kopiował z nich za duże
  // auto i przybliżony kadr jako „Image 3” i „Image 4”.
  return wynik
}

/**
 * Wycinek zdjęcia wokół pineski — to, co widać w podglądzie „Zaznaczono
 * obiekt” i na chipie. Robione w pamięci, bez zapisu: dataURL wycinków
 * przy kilkunastu pineskach wysadziłby localStorage.
 */
export function wytnijOkolice(
  src: string,
  normalizedX: number,
  normalizedY: number,
  bok = 96,
  udzial = 0.22,
): Promise<string> {
  return new Promise(resolve => {
    const obrazek = new Image()
    obrazek.onload = () => {
      const zrodloBok = Math.max(24, Math.min(obrazek.width, obrazek.height) * udzial)
      const sx = Math.max(0, Math.min(obrazek.width - zrodloBok, obrazek.width * normalizedX - zrodloBok / 2))
      const sy = Math.max(0, Math.min(obrazek.height - zrodloBok, obrazek.height * normalizedY - zrodloBok / 2))

      const plotno = document.createElement('canvas')
      plotno.width = bok
      plotno.height = bok
      const g = plotno.getContext('2d')
      if (!g) return resolve('')
      g.drawImage(obrazek, sx, sy, zrodloBok, zrodloBok, 0, 0, bok, bok)
      resolve(plotno.toDataURL('image/png'))
    }
    obrazek.onerror = () => resolve('')
    obrazek.src = src
  })
}

/**
 * Podgląd obiektu przy pineskach: gdy znamy ramkę obiektu — kwadrat obejmujący
 * go w całości z zapasem (pineska w masce auta pokazuje całe auto); gdy obiekt
 * zajmuje niemal cały kadr, wychodzi prawie całe zdjęcie — bez sztucznego
 * przybliżania. Bez ramki: szeroki kadr wokół pinu zamiast ciasnego skrawka.
 */
export function wytnijPodgladPineski(src: string, p: Pineska, bok = 96): Promise<string> {
  const r = p.ramka
  if (!r) return wytnijOkolice(src, p.normalizedX, p.normalizedY, bok, 0.6)
  return new Promise(resolve => {
    const obrazek = new Image()
    obrazek.onload = () => {
      const szer = (r.x1 - r.x0) * obrazek.width
      const wys = (r.y1 - r.y0) * obrazek.height
      const maks = Math.min(obrazek.width, obrazek.height)
      const zrodloBok = Math.min(maks, Math.max(48, Math.max(szer, wys) * 1.4))
      const cx = ((r.x0 + r.x1) / 2) * obrazek.width
      const cy = ((r.y0 + r.y1) / 2) * obrazek.height
      const sx = Math.max(0, Math.min(obrazek.width - zrodloBok, cx - zrodloBok / 2))
      const sy = Math.max(0, Math.min(obrazek.height - zrodloBok, cy - zrodloBok / 2))
      const plotno = document.createElement('canvas')
      plotno.width = bok
      plotno.height = bok
      const g = plotno.getContext('2d')
      if (!g) return resolve('')
      g.drawImage(obrazek, sx, sy, zrodloBok, zrodloBok, 0, 0, bok, bok)
      resolve(plotno.toDataURL('image/jpeg', 0.9))
    }
    obrazek.onerror = () => resolve('')
    obrazek.src = src
  })
}

/**
 * Stan generacji — od planu do oceny.
 *
 * Fazy `planuje` i `sprawdza` istnieją, bo pętla z agentem trwa dłużej niż
 * sama generacja, a człowiek ma prawo wiedzieć, na co czeka. Bez nich
 * kręciołek przez pół minuty nie mówiłby nic.
 */
export type StanGeneracji =
  | { faza: 'bezczynny' }
  | { faza: 'planuje' }
  /** `role` — skąd wiadomo, co jest obiektem, a co miejscem (po polsku) */
  | { faza: 'trwa'; plan?: string; role?: string; tryb?: 'inpainting' | 'generator' | 'referencje' }
  /** poziom 4: ani zdanie, ani wzrok nie rozstrzygnęły ról — pytamy jednym kliknięciem */
  | { faza: 'pyta'; pytanie: import('./role-z-polecenia').PytanieORole }
  | { faza: 'sprawdza'; wynik: import('./dostawca').Generacja }
  /** pomiar pokazał za duży / za mały obiekt albo przesunięty od pineski — generujemy jeszcze raz */
  | { faza: 'koryguje'; wynik: import('./dostawca').Generacja; powod: string }
  /** drugi przebieg: kontrola uznała, że zmieniony element wygląda na wklejony */
  | { faza: 'poprawia'; wynik: import('./dostawca').Generacja }
  | { faza: 'blad'; tresc: string }
  | {
      faza: 'gotowe'
      wynik: import('./dostawca').Generacja
      ocena?: import('./agent-proxy').Sprawdzenie
    }

/**
 * Zmniejszona kopia zdjęcia do analizy.
 *
 * Model opisujący dostawał dotąd oryginał — przy zdjęciu 1684×2528 to prawie
 * 5 MB w base64 i Runware odrzucał takie żądania błędem 500. Rozpoznanie
 * nazw nie potrzebuje pełnej rozdzielczości: 768 px wystarczy, żeby wymienić
 * obiekty, a żądanie robi się kilkadziesiąt razy lżejsze.
 */
export function zmniejszDoAnalizy(src: string, bok = 768): Promise<string> {
  return new Promise(resolve => {
    const obrazek = new Image()
    obrazek.crossOrigin = 'anonymous'
    obrazek.onload = () => {
      const skala = Math.min(1, bok / Math.max(obrazek.width, obrazek.height))
      const plotno = document.createElement('canvas')
      plotno.width = Math.round(obrazek.width * skala)
      plotno.height = Math.round(obrazek.height * skala)
      const g = plotno.getContext('2d')
      if (!g) return resolve('')
      g.drawImage(obrazek, 0, 0, plotno.width, plotno.height)
      resolve(plotno.toDataURL('image/jpeg', 0.85))
    }
    obrazek.onerror = () => resolve('')
    obrazek.src = src
  })
}

/**
 * Twarda blokada formatu wyniku do proporcji zdjęcia docelowego (Image 1), BEZ utraty jakości.
 *
 * Nano-Banana ignoruje żądane width/height i potrafi oddać wynik w formacie zdjęcia referencyjnego (np. pionowa kaczka zamiast poziomego
 * kadru z gęsiami). Sam prompt tego nie wymusza, więc przycinamy wynik („cover”, centralnie) do proporcji Image 1.
 *
 * Jakość: model oddaje ok. 1 Mpx, a zdjęcie źródłowe bywa kilka razy większe. Wcześniej wynik był skalowany do pikseli Image 1 (sztuczne
 * powiększenie = miękki obraz) i dwukrotnie kodowany do JPEG. Teraz:
 *  - proporcje zgodne w granicach 2% → wynik wraca NIETKNIĘTY (zero rekompresji, zero resamplingu);
 *  - inaczej tylko przycięcie na natywnej rozdzielczości, zapis bezstratny (PNG; przy bardzo dużych obrazach JPEG 0.97);
 *  - skalowanie do wymiarów docelowych tylko na wyraźne życzenie (`skaluj`, np. „Upscale 2×”), z wysoką jakością resamplingu.
 * Rozmiar warstwy na płótnie nie zależy od pikseli obrazu (wysokość bierze się ze wzorca), więc nic się nie rozjeżdża.
 *
 * Przy błędzie (np. tainted canvas z powodu CORS) zwraca oryginał — lepiej oddać zły format niż nic.
 */
export function dopasujFormatDoObrazu(
  src: string,
  docelowaSzer: number,
  docelowaWys: number,
  opcje: { skaluj?: boolean } = {},
): Promise<string> {
  if (!Number.isFinite(docelowaSzer) || !Number.isFinite(docelowaWys) || docelowaSzer < 1 || docelowaWys < 1) {
    return Promise.resolve(src)
  }
  return new Promise(resolve => {
    const obrazek = new Image()
    obrazek.crossOrigin = 'anonymous'
    obrazek.onload = () => {
      try {
        const aCel = docelowaSzer / docelowaWys
        const aObraz = obrazek.width / obrazek.height
        if (!opcje.skaluj && Math.abs(aObraz / aCel - 1) < 0.02) return resolve(src)
        // wycinek „cover” w pikselach obrazu
        let sw = obrazek.width
        let sh = obrazek.height
        if (aObraz > aCel) sw = Math.round(sh * aCel)
        else sh = Math.round(sw / aCel)
        const sx = Math.round((obrazek.width - sw) / 2)
        const sy = Math.round((obrazek.height - sh) / 2)
        const plotno = document.createElement('canvas')
        plotno.width = opcje.skaluj ? Math.round(docelowaSzer) : sw
        plotno.height = opcje.skaluj ? Math.round(docelowaWys) : sh
        const g = plotno.getContext('2d')
        if (!g) return resolve(src)
        g.imageSmoothingEnabled = true
        g.imageSmoothingQuality = 'high'
        g.drawImage(obrazek, sx, sy, sw, sh, 0, 0, plotno.width, plotno.height)
        const duzy = plotno.width * plotno.height > 12_000_000
        resolve(duzy ? plotno.toDataURL('image/jpeg', 0.97) : plotno.toDataURL('image/png'))
      } catch {
        resolve(src)
      }
    }
    obrazek.onerror = () => resolve(src)
    obrazek.src = src
  })
}

/**
 * Konwersja adresu (np. z assets Vite lub blob) na Data URI, aby Runware API w chmurze
 * mogło bezbłędnie przetworzyć referencje obrazów.
 */
export function konwertujNaDataUrl(src: string): Promise<string> {
  if (src.startsWith('data:')) return Promise.resolve(src)
  return new Promise(resolve => {
    const obrazek = new Image()
    obrazek.crossOrigin = 'anonymous'
    obrazek.onload = () => {
      const plotno = document.createElement('canvas')
      plotno.width = obrazek.width
      plotno.height = obrazek.height
      const g = plotno.getContext('2d')
      if (!g) return resolve(src)
      g.drawImage(obrazek, 0, 0)
      resolve(plotno.toDataURL('image/jpeg', 0.98))
    }
    obrazek.onerror = () => resolve(src)
    obrazek.src = src
  })
}

