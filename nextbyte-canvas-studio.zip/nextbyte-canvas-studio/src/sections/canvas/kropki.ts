/**
 * Mała magentowa kropka w miejscu pineski — na kopii zdjęcia wysyłanej do
 * modelu obrazu. Kropka + jej współrzędne w prompcie (`PIN MAP`) to jedno
 * wskazanie miejsca; kontrakt wyniku każe ją usunąć z obrazu.
 */
export interface PunktKropki {
  /** 0–1 od lewej krawędzi */
  x: number
  /** 0–1 od górnej krawędzi */
  y: number
  /** kolor tej kropki; domyślnie kolor wywołania */
  kolor?: string
}

/** Promień kropki: mały, ale widoczny w każdej rozdzielczości. */
export function promienKropki(szer: number, wys: number): number {
  return Math.max(4, Math.round(Math.min(szer, wys) * 0.007))
}

/** Zwraca kopię obrazu z kropkami (data URI, pełna rozdzielczość). Przy błędzie — obraz bez zmian. */
/** `kolor`: domyślnie magenta (obiekt); jasna czerwień oznacza miejsce docelowe przy przeniesieniu w kadrze. */
export function narysujKropki(src: string, punkty: PunktKropki[], kolor = '#FF00FF', mnoznikPromienia = 1): Promise<string> {
  if (!punkty.length) return Promise.resolve(src)
  return new Promise(resolve => {
    const obraz = new Image()
    obraz.crossOrigin = 'anonymous'
    obraz.onload = () => {
      try {
        const plotno = document.createElement('canvas')
        plotno.width = obraz.naturalWidth
        plotno.height = obraz.naturalHeight
        const g = plotno.getContext('2d')
        if (!g) return resolve(src)
        g.drawImage(obraz, 0, 0)
        const r = Math.round(promienKropki(plotno.width, plotno.height) * mnoznikPromienia)
        for (const p of punkty) {
          g.beginPath()
          g.arc(p.x * plotno.width, p.y * plotno.height, r, 0, Math.PI * 2)
          g.fillStyle = p.kolor ?? kolor
          g.fill()
        }
        resolve(plotno.toDataURL('image/jpeg', 0.95))
      } catch {
        resolve(src)
      }
    }
    obraz.onerror = () => resolve(src)
    obraz.src = src
  })
}
