# Tryb skandynawski (Scandinavian) — dodaj do projektu

Plik `tryb-skandynawski.css` zawiera jeden blok `[data-theme="scandinavian"]` z tokenami HSL
(ciepły kremowy jasny motyw, szałwiowy akcent `161 22% 40%`).

## Co zrobić
1. Wklej zawartość `tryb-skandynawski.css` do głównego pliku stylów (np. `src/index.css`), obok pozostałych bloków `[data-theme="..."]`. Nie zmieniaj wartości.
2. Dodaj motyw `scandinavian` do listy motywów i przełącznika (id: `scandinavian`, etykieta: `Scandi`, jasny, bez dodawania żadnych paczek).
3. Motyw jest JASNY — dodaj `[data-theme="scandinavian"]` tam, gdzie projekt grupuje jasne motywy (szkło, logo `brightness-0 opacity-85`, kolory kategorii).
4. Zasady: tylko tokeny HSL (`bg-card`, `text-foreground`, `border-border`…), zero `bg-black` / `text-white`, bez nowych paczek npm, ikony tylko `lucide-react`.
5. Sprawdź: `document.documentElement.setAttribute('data-theme','scandinavian')` — tło kremowe, tekst ciemny, akcent szałwiowy, brak niebieskawej mgły.
